package nl.rijnijssel.medicijnenapp.edit;

/**
 * Created by Rik on 27-11-2015.
 */
public enum DayEnum
{
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
